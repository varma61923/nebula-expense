package com.example.offline_expense_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
